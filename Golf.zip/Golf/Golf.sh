#!/bin/bash
cd ~/Golf
java -jar Golf.jar